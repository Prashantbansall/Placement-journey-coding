// write a program to find the area of circle//
#include<stdio.h>
int main()
{
    int r;
    float a;
    printf("enter radiusof circle");
    scanf("%d",&r);
    a=3.14*r*r;
    printf("area of circle is %f",a);
}