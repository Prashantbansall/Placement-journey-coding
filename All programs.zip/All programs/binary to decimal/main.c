#include <stdio.h>
#include<math.h>
int main()
{
    int n,c=0,r,s=0;
    printf("Enter the binary form of a number");
    scanf("%d",&n);
    while(n>0){
        r=n%10;
        s+=r*(int)pow(2,c++);
        n=n/10;
    }
    printf("Decimal form of the number is:%d",s);
    return 0;
}
