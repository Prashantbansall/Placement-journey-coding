#include <stdio.h>
int main()
{
    int n,num;
    scanf("%d",&n);
    scanf("%d",&num);
    int *ptr=&n;
    *ptr=num;
    printf("New value of n =%d",n);
    return 0;
}
