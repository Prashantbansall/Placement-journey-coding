#include <stdio.h>
int main()
{
    char ch;
    printf("Enter any character\n");
    scanf("%c",&ch);
    printf("ASCII code of character%c=%d",ch,ch);
    return 0;
}