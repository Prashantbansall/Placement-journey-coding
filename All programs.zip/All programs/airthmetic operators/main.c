#include <stdio.h>
#include<math.h>
int main()
{
    int a,b;
    float power;
    printf("Enter the value of numbers a \n");
    scanf("%d",&a);
    printf("Enter the value of numbers b \n");
    scanf("%d",&b);
    printf("sum=%d \n",a+b);
    printf("pro=%d \n",a*b);
    printf("diff=%d \n",a-b);
    printf("quo=%d \n",a/b);
    printf("power=%d \n",pow(a,b));
    printf("rem=%d \n",a%b);
    return 0;
}