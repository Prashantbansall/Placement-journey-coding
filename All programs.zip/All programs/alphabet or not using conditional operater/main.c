#include<stdio.h>
int main()
{
   char ch;
   scanf("%c",&ch);
   (ch>=65&&ch<=90)||(ch>=97&&ch<=122)?printf("Alphabet"):printf("NOT");
    return 0;
}
