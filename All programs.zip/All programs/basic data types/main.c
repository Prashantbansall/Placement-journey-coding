#include <stdio.h>
int main()
{
    char ch;
    int num;
    float d;
    printf("Enter any character\n");
    scanf("%c",&ch);
    printf("Enter any number\n");
    scanf("%d",&num);
    printf("Enter any decimal number\n");
    scanf("%f",&d);
    printf("%c \n",ch);
    printf("%d \n",num);
    printf("%f \n",d);
    return 0;
}
