#include <stdio.h>
int main()
{
    float r;
    printf("Enter radius of circle\n");
    scanf("%f",&r);
    printf("Circumference of circle is %f\n ", 2*3.14*r);
    printf("Area of circle is %f \n ",3.14*r*r);
    printf("Diameter of circle is %f\n ", 2*r);
    return 0;
}