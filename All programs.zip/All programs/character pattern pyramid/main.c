#include <stdio.h>
int main()
{
   int i,j,k,l,n,a;
   scanf("%d",&n);
   a=n-1;
   for(i=1;i<=n;i++)
   {
       for(l=a;l>=1;l--)
       {
           printf(" ");
       }
            for(k=i;k>=2;k--)
            {
               printf("%c",64+k);
            }
       for(j=1;j<=i;j++)
       {
            printf("%c",64+j);
       }
           a--;
           printf("\n");
   }
    return 0;
}