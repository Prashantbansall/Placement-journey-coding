#include <stdio.h>
int main()
{
    int l,b;
    printf("Enter length of rectangle\n");
    scanf("%d",&l);
    printf("Enter breadth of rectangle\n");
    scanf("%d",&b);
    printf("Area of rectangle=%d",l*b);
    return 0;
}
