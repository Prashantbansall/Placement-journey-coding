#include <stdio.h>
int main()
{
   int b,h;
   printf("Enter base of triangle\n");
   scanf("%d",&b);
   printf("Enter height of triangle\n");
   scanf("%d",&h);
   printf("Area of triangle=%f",0.5*b*h);
   return 0;
}