#include <stdio.h>
int main()
{
    char str[100];
    scanf("%[^\n]c",str);
    int i;
    for(i=0;str[i]!=0;i++);
    printf("%d",i);
    return 0;
}
