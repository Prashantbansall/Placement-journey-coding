#include <stdio.h>
int main()
{
    int temp;
    printf("Enter temperature in Celsius\n");
    scanf("%d",&temp);
    printf("Temperature in Fahrenheit=%d",(9*temp/5)+32);
    return 0;
}