/*
   2
   34
   456
   5678
   678910 .......
*/

#include<stdio.h>
int main()
{
    int i,j,n;
    printf("Enter no. of lines : ");
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            printf("%d",i+j);
        }
        printf("\n");
    }
    return 0;
}